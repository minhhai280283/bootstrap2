(function($) {
    $.fn.loading.algorithm('linear', function(matrix, _) {

    });
}).call(this, jQuery);

