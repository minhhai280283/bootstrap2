CHANGELOG
=========

### 0.2.2 (xx-xx-2013)
______________________

 + Bug fix if vertical (-)
 + JSHint valid (-)

### 0.2.1 (03-03-2013)
______________________

 + Build management via grunt
 + Added jquery manifest
 + First alpha version of site (gh-pages branch)
 + Little improvements

### 0.2.0 (31-03-2013)
______________________

 + Separated logic in different files
 + A lot of refactoring
 + Added effects stacks functionality
 + Added setters for user-defined algorithms
 + Added setters for user-defined effects

### 0.1.3 (30-03-2013)
______________________

 + Completed Snake algorithm

### 0.1.1 (25-03-2013)
______________________

 + Added some functionality for effect&algorithm callbacks

### 0.1.0 (22-03-2013)
______________________

 + Initial commit