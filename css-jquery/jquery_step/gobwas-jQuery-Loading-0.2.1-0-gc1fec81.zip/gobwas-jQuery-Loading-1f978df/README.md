jQuery Loading Plugin
=====================

This is a simple jQuery loading plugin, that draws animations via DOM elements,
with ability to push your own effects&algorithms for animations.

It also have predefined algorithms and effects.

Algorithms
----------

 + Snake


Effects
-------

 + Simple show/hide effect

Creating your own animations
============================

Creating your own algorithm
---------------------------

n/a

Creating your own effect
------------------------

n/a